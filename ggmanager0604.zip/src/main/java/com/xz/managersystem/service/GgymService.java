package com.xz.managersystem.service;

import com.xz.managersystem.dao.GgymMapper;
import com.xz.managersystem.entity.TGgym;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GgymService {

    @Autowired
    GgymMapper mapper;

    public List<TGgym> selectAll() {
        return mapper.selectAll();
    }

    public int insert(TGgym tGgym) {
        return mapper.insert(tGgym);
    }

    public int updateByPrimaryKeySelective(TGgym tGgym) {
        return mapper.updateByPrimaryKeySelective(tGgym);
    }

    public int delete(TGgym tGgym) {
        return mapper.delete(tGgym);
    }

}
