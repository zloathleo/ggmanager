package com.xz.managersystem.service;

import com.xz.managersystem.dao.GgmbMapper;
import com.xz.managersystem.entity.TGgmb;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GgmbService {

    @Autowired
    GgmbMapper mapper;

    public List<TGgmb> selectAll() {
        return mapper.selectAll();
    }

}
