package com.xz.managersystem.dao;

import com.xz.managersystem.entity.TGgmb;
import org.apache.ibatis.annotations.Select;
import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.common.MySqlMapper;

import java.util.List;

public interface GgmbMapper extends Mapper<TGgmb> , MySqlMapper<TGgmb> {

    @Select("SELECT t.id,t.name,t.desc,t.type,t.content,t.create_time,t.update_time  FROM t_ggmb t")
    List<TGgmb> selectAll();

}
