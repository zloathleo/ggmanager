package com.xz.managersystem.dao;

import com.xz.managersystem.entity.TGgym;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.common.MySqlMapper;

import java.util.List;

public interface GgymMapper extends Mapper<TGgym>, MySqlMapper<TGgym> {

    @Select("SELECT \n" +
            "  t.id,\n" +
            "  t.name,\n" +
            "  t.desc,\n" +
            "  t.ggmb_id,\n" +
            "  t.video_urls,\n" +
            "  t.img_urls,\n" +
            "  t.create_time,\n" +
            "  t.update_time,\n" +
            "  b.name AS mbname,\n" +
            "  b.content \n" +
            "FROM t_ggym t  LEFT JOIN t_ggmb b  ON t.ggmb_id = b.id ")
    List<TGgym> selectAll();

    @Insert("INSERT INTO t_ggym (`name`, `desc`, `ggmb_id` ,`video_urls` ,`img_urls`) VALUES (#{name},#{desc},#{ggmbId},#{videoUrls},#{imgUrls})")
    int insert(TGgym tGgym);

    @Update("update t_ggym t set t.desc=#{desc},t.ggmb_id=#{ggmbId},t.video_urls=#{videoUrls} ,t.img_urls=#{imgUrls} where t.id=#{id}")
    int updateByPrimaryKeySelective(TGgym tGgym);

    @Delete("DELETE FROM t_ggym WHERE id=#{id}")
    int delete(TGgym tGgym);

}
