package com.xz.managersystem.entity;

import java.io.Serializable;

public class BasicEntity implements Serializable {

    private static final long serialVersionUID = 1L;

}