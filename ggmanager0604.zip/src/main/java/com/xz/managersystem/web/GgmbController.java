package com.xz.managersystem.web;

import com.xz.managersystem.entity.TGgmb;
import com.xz.managersystem.service.GgmbService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

//广告模板
@Controller
@RequestMapping("/Views/ggmb")
public class GgmbController {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    GgmbService ggmbService;

    @RequestMapping(value = "/search", method = RequestMethod.GET)
    private String search(Model model) {
        List<TGgmb> list = ggmbService.selectAll();

        model.addAttribute("data", list);
//        model.addObject("users",users);
        return "/Views/ggmb/search";
    }

}
