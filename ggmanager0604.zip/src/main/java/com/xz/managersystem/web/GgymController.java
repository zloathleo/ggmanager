package com.xz.managersystem.web;

import com.xz.managersystem.entity.TGgmb;
import com.xz.managersystem.entity.TGgym;
import com.xz.managersystem.service.GgmbService;
import com.xz.managersystem.service.GgymService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping("/Views/ggym")
public class GgymController {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    GgymService ggymService;

    @Autowired
    GgmbService ggmbService;

    @RequestMapping(value = "/search", method = RequestMethod.GET)
    private String search(Model model) {
        List<TGgym> list = ggymService.selectAll();
        model.addAttribute("data", list);
        return "/Views/ggym/search";
    }

    @RequestMapping(value = "/add_item", method = RequestMethod.POST)
    private String addItem(@Valid TGgym ggym) {
        int count = ggymService.insert(ggym);
        return "redirect:/Views/ggym/search.html";
    }

    @RequestMapping(value = "/update_item", method = RequestMethod.POST)
    private String updateItem(@Valid TGgym ggym) {
        int count = ggymService.updateByPrimaryKeySelective(ggym);
        return "redirect:/Views/ggym/search.html";
    }

    @RequestMapping(value = "/delete_item", method = RequestMethod.POST)
    private String deleteItem(@Valid TGgym ggym) {
        int count = ggymService.delete(ggym);
        return "redirect:/Views/ggym/search.html";
    }

    @RequestMapping(value = "/open_operate", method = RequestMethod.GET)
    private String openOperate(Model model, @RequestParam(name = "cmd", required = false) String cmd, @RequestParam(name = "itemId", required = false) String itemId) {
        List<TGgmb> list = ggmbService.selectAll();
        model.addAttribute("data", list);
        return "/Views/ggym/add";
    }

}
