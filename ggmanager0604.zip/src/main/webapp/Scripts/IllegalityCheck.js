function CheckPage() {
//    try {
//        
//        if (parent.ck != "CSJ") {
//            window.location = '/Login.aspx'
//        }
//    } catch (e) {
//        window.location = '/Login.aspx'
//    }
}
CheckPage();